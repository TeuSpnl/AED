public class ObjetoNaoEncontradoException extends Exception {

}
