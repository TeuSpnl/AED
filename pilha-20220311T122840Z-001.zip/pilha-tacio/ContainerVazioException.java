public class ContainerVazioException extends Exception {
    
}
