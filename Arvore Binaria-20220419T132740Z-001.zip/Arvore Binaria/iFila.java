public interface iFila {

    void fazVazia();

    boolean estaVazia();

    Object getPrimeiro();

    void enfileirar(Object objeto);

    Object desenfileirar();

}
