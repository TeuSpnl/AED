public class ListaVaziaException extends Exception{
    
}
