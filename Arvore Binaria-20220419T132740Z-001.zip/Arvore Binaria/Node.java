public class Node<T> {

  private T valor;
  private Node<T> filho_esq, filho_dir;

  public Node(T v) {
    valor = v;
    filho_esq = null;
    filho_dir = null;
  }

  public Node(T v, Node<T> filho_esq, Node<T> filho_dir) {
    valor = v;
    this.filho_esq = filho_esq;
    this.filho_dir = filho_dir;
  }

  public void inserirOrdenado(T v) {
    if (v.toString().compareTo(this.getValor().toString()) < 0) { // menor
      if (this.getFilho_esq() != null) {
        this.getFilho_esq().inserirOrdenado(v);
      } else {
        Node<T> n = new Node<T>(v);
        this.setFilho_esq(n);
      }
    } else { // maior ou igual
      if (this.getFilho_dir() != null) {
        this.getFilho_dir().inserirOrdenado(v);
      } else {
        Node<T> n = new Node<T>(v);
        this.setFilho_dir(n);
      }
    }
  }

  public void imprimeInOrdem() {
    if (this.getFilho_esq() != null) {
      this.getFilho_esq().imprimeInOrdem();
    }

    System.out.print(this.valor + " "); // visita o no

    if (this.getFilho_dir() != null) {
      this.getFilho_dir().imprimeInOrdem();
    }
  }

  public void imprimeDesOrdem() {
    if (this.getFilho_dir() != null) {
      this.getFilho_dir().imprimeDesOrdem();
    }

    System.out.print(this.valor + " "); // visita o no

    if (this.getFilho_esq() != null) {
      this.getFilho_esq().imprimeDesOrdem();
    }
  }

  // Gets n Sets
  public T getValor() {
    return valor;
  }

  public void setValor(T valor) {
    this.valor = valor;
  }

  public Node<T> getFilho_esq() {
    return filho_esq;
  }

  public void setFilho_esq(Node<T> filho_esq) {
    this.filho_esq = filho_esq;
  }

  public Node<T> getFilho_dir() {
    return filho_dir;
  }

  public void setFilho_dir(Node<T> filho_dir) {
    this.filho_dir = filho_dir;
  }

  // pesquisarprofundidadepreordem
  // pesquisarprofundidadeinordem
  // pesquisarprofundidadeposordem
  // pesquisaremLargura
  // remover
  // imprimir a arvore: em profundidade preordem
  // em profundidade posordem
  // em profundidade inordem
  // em largura

  // calcular o comprimento do caminho entre dois nos
  // calcular altura de um node
  // verificar se um node eh interno ou externo
  // calcular a profundidade de um node

  protected void imprimeEmLarguraRecursivo(iFila f) {
    if (!f.estaVazia()) {
      Node<T> no = (Node<T>) f.desenfileirar();

      if (no != null) {
        if (no.getFilho_esq() != null) {
          f.enfileirar(no.getFilho_esq());
        }
        if (no.getFilho_dir() != null) {
          f.enfileirar(no.getFilho_dir());
        }
        System.out.println(no.getValor());

        this.imprimeEmLarguraRecursivo(f);
      }
    }
  }

  protected void imprimeEmLarguraInverso() {
    FilaEncadeada f = new FilaEncadeada();
    java.util.Stack<String> pl = new java.util.Stack<String>();

    f.enfileirar(this);

    while (!f.estaVazia()) {
      Node<T> no = (Node<T>) f.desenfileirar();

      if (no.getFilho_esq() != null) {
        f.enfileirar(no.getFilho_esq());
      }
      if (no.getFilho_dir() != null) {
        f.enfileirar(no.getFilho_dir());
      }

      pl.push(no.getValor().toString());
    }
  }

  protected int calculaAltura() {
    int alturaE = 0;
    int alturaD = 0;

    if (this.getFilho_esq() != null) {
      alturaE = this.getFilho_esq().calculaAltura() + 1;
    }
    if (this.getFilho_dir() != null) {
      alturaD = this.getFilho_dir().calculaAltura() + 1;
    }

    if (alturaE > alturaD) {
      return alturaE;
    }
    return alturaD;
  }

  protected int calculaAlturaEmLargura() {
    FilaEncadeada f = new FilaEncadeada();
    FilaEncadeada dist = new FilaEncadeada();

    f.enfileirar(this);

    int altura_maxima = 0;

    while (!f.estaVazia()) {
      Node<T> no = (Node<T>) f.desenfileirar();
      int dist_pai = (int) dist.desenfileirar();

      if (no.getFilho_esq() != null) {
        f.enfileirar(no.getFilho_esq());
        dist.enfileirar(dist_pai + 1);
      }
      if (no.getFilho_dir() != null) {
        f.enfileirar(no.getFilho_dir());
        dist.enfileirar(dist_pai + 1);
      }

      if (dist_pai > altura_maxima) {
        altura_maxima = dist_pai;
      }

    }
    return altura_maxima;
  }
}
